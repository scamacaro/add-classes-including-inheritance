﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Live_Class_092622_Notes
{
    public partial class Form1 : Form
    {
        class employee
        {// attributes
            protected string fname;
            protected string lname;

            public employee(string fn, string ln)
            {
                this.fname = fn;
                this.lname = ln;
                MessageBox.Show(" employee constructor");
            }
            public void display()
            {
                MessageBox.Show(" inside display" + this.fname + ' ' + this.lname);
            }

            public string getfn()
            { return this.fname; }

            public void setfn(string fn)
            {
                this.fname = fn;
            }
        }
        class FT:employee
        {
            //attributes
            private double salary;

            public FT(string fn, string ln, double sal):base(fn,ln)
            {
                this.salary = sal;
            }

            public void displayFT()
            {
                base.display();
                MessageBox.Show("inside FT Display" + this.salary.ToString());
            }
        }

        class PT: employee
        {
            //attributes
            private int hoursWorked;

            public PT(string fn, string ln, int hw ) : base(fn,ln)
            {

                this.hoursWorked = hw;
            }
            public void displayPT()
            {
                base.display();
                MessageBox.Show("inside PT display" + this.hoursWorked.ToString());
            }
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            employee e1 = new employee(textBox1.Text, textBox2.Text);
            e1.display();
            employee e2 = new employee("jill", "Coddington");
            e2.display();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox3.Visible = true;
            MessageBox.Show("Please enter salary");
            double sal = double.Parse(textBox3.Text);
            FT f1 = new FT(textBox1.Text, textBox2.Text, sal);
            f1.displayFT();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Please enter hours worked");
            int hw = int.Parse(textBox3.Text);
            PT P1 = new PT(textBox1.Text, textBox2.Text, hw);
            P1.displayPT();
        }
    }
}
